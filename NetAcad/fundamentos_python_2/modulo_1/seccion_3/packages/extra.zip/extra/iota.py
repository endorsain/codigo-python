#! src/bin/env python3

""" module: extra.iota """

def funI():
    return 'Iota'

if __name__ == "__main__":
    print('Prefiero ser un modulo')
