#! src/bin/env python3

""" module: extra.good.alpha """

def funA():
    return 'Alpha'

if __name__ == "__main__":
    print('Prefiero ser un modulo')