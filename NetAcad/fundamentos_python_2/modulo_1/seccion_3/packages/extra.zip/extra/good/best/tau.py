#! src/bin/env python3

""" module: extra.good.best.tau """

def funT():
    return 'Tau'

if __name__ == "__main__":
    print('Prefiero ser un modulo')