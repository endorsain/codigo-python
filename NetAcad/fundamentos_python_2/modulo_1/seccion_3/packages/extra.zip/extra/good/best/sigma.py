#! src/bin/env python3

""" module: extra.good.best.sigma """

def funS():
    return 'Sigma'

if __name__ == "__main__":
    print('Prefiero ser un modulo')