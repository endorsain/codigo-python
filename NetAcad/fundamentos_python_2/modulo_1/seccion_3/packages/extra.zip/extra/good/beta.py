#! src/bin/env python3

""" module: extra.good.beta """

def funB():
    return 'Beta'

if __name__ == "__main__":
    print('Prefiero ser un modulo')