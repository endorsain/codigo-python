#! src/bin/env python3

""" module: extra.ugly.psi """

def funP():
    return 'Psi'

if __name__ == "__main__":
    print('Prefiero ser un modulo')