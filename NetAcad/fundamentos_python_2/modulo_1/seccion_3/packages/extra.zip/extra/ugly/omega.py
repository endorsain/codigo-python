#! src/bin/env python3

""" module: extra.ugly.omega """

def funO():
    return 'Omega'

if __name__ == "__main__":
    print('Prefiero ser un modulo')